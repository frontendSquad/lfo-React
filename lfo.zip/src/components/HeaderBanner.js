function HeaderBanner(){
    return (
        <section class="header-wrapper">
            <div class="header-banner">
                <div class="container-fluid p-0">
                    <div class="row g-0">
                        <div class="col-12 col-lg-6 col-xxl-5 align-self-center">
                            <div class="pe-5 pe-lg-4">
                                <h3 class="text-uppercase">LFO UK I LONDON FAMILY OFFICE</h3>
                                <h2 class="mb-3">Educational<br /> Consultancy & <br /><span class="text-maroon">Tutoring</span>
                                </h2>
                                <p class="mb-2">We are primarily an education consultancy, offering services to high net-worth clients throughout China and the UK. </p>
                                <a class="btn btn-primary mt-2 px-5" href="#">REGISTER YOUR INTEREST</a>
                            </div>
                        </div>
                        <div class="col-12 col-lg-6 col-xxl-7 text-end d-none d-lg-block">
                            <img src="images/header-banner.png" alt="" class="img-fluid" />
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}
export default HeaderBanner