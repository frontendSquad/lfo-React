function HomeServices(props){
    return(
        <section class="section services-sec">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="sec-title mb-3 mb-lg-5">
                            <h5 class="text-uppercase fs-18 fw-semibold text-maroon mb-2">SPECIAL FEATURES</h5>
                            <h3 class="fw-bold mb-3">Services We Provide</h3>
                        </div>
                    </div>
                    <div class="col-12 col-lg-6 col-xl-5 mb-3 mb-lg-5">
                        <div class="card service-card">
                            <div class="card-header px-0">
                                <i class="card-icon mb-4"> <img src="images/srv-icon-1.png" alt="" /></i>
                                <h3 class="card-title">Tutor Profiles</h3>
                            </div>
                            <div class="card-body px-0">
                                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                                    eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimminim veniam, quis nostrud exercitation ullamco laboris...</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-6 col-xl-5 mb-3 mb-lg-5">
                        <div class="card service-card">
                            <div class="card-header px-0">
                                <i class="card-icon mb-4"> <img src="images/srv-icon-2.png" alt="" /></i>
                                <h3 class="card-title">Tutoring Services</h3>
                            </div>
                            <div class="card-body px-0">
                                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                                    eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimminim veniam, quis nostrud exercitation ullamco laboris...</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-6 col-xl-5 mb-3 mb-lg-5">
                        <div class="card service-card">
                            <div class="card-header px-0">
                                <i class="card-icon mb-4"> <img src="images/srv-icon-3.png" alt="" /></i>
                                <h3 class="card-title">University Application</h3>
                            </div>
                            <div class="card-body px-0">
                                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                                    eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimminim veniam, quis nostrud exercitation ullamco laboris...</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-6 col-xl-5 mb-3 mb-lg-5">
                        <div class="card service-card">
                            <div class="card-header px-0">
                                <i class="card-icon mb-4"> <img src="images/srv-icon-4.png" alt="" /></i>
                                <h3 class="card-title">Tutor Listing</h3>
                            </div>
                            <div class="card-body px-0">
                                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                                    eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimminim veniam, quis nostrud exercitation ullamco laboris...</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}
export default HomeServices;
