function HomeTestimonials(){
return(
    <section id="client-review" class="section client-review">
        <div class="container-fluid px-3 px-md-5">
            <div class="row">
                <div class="col-12">
                    <div class="sec-title mb-2 text-center">
                        <h5 class="text-uppercase fs-18 fw-semibold text-maroon mb-2">TESTIMONIALS </h5>
                        <h3 class="fw-bold mb-3">What Client Say </h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="client-carousel owl-theme owl-carousel">
                        <div class="item card client-card">
                            <div class="card-content text-center">
                                <i class="quote-left mb-3"><img src="images/quote-icon.png" alt="" class="img-fluid" /> </i>
                                <blockquote>There are many variations of passages of lorem ipsum available but the majority have suffered alteration in some form. </blockquote>
                                <div class="author d-flex flex-column align-items-center">
                                    <h5>- Kevin Martin</h5>
                                    <div class="mt-3 text-center avatar-img">
                                        <img src="images/testimonial-pic.png" alt="" class="img-fluid" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item card client-card">
                            <div class="card-content text-center">
                                <i class="quote-left mb-3"><img src="images/quote-icon.png" alt="" class="img-fluid" /> </i>
                                <blockquote>There are many variations of passages of lorem ipsum available but the majority have suffered alteration in some form. </blockquote>
                                <div class="author d-flex flex-column align-items-center">
                                    <h5>- Kevin Martin</h5>
                                    <div class="mt-3 text-center avatar-img">
                                        <img src="images/testimonial-pic.png" alt="" class="img-fluid" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item card client-card">
                            <div class="card-content text-center">
                                <i class="quote-left mb-3"><img src="images/quote-icon.png" alt="" class="img-fluid" /> </i>
                                <blockquote>There are many variations of passages of lorem ipsum available but the majority have suffered alteration in some form. </blockquote>
                                <div class="author d-flex flex-column align-items-center">
                                    <h5>- Kevin Martin</h5>
                                    <div class="mt-3 text-center avatar-img">
                                        <img src="images/testimonial-pic.png" alt="" class="img-fluid" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item card client-card">
                            <div class="card-content text-center">
                                <i class="quote-left mb-3"><img src="images/quote-icon.png" alt="" class="img-fluid" /> </i>
                                <blockquote>There are many variations of passages of lorem ipsum available but the majority have suffered alteration in some form. </blockquote>
                                <div class="author d-flex flex-column align-items-center">
                                    <h5>- Kevin Martin</h5>
                                    <div class="mt-3 text-center avatar-img">
                                        <img src="images/testimonial-pic.png" alt="" class="img-fluid" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item card client-card">
                            <div class="card-content text-center">
                                <i class="quote-left mb-3"><img src="images/quote-icon.png" alt="" class="img-fluid" /> </i>
                                <blockquote>There are many variations of passages of lorem ipsum available but the majority have suffered alteration in some form. </blockquote>
                                <div class="author d-flex flex-column align-items-center">
                                    <h5>- Kevin Martin</h5>
                                    <div class="mt-3 text-center avatar-img">
                                        <img src={process.env.PUBLIC_URL + "images/testimonial-pic.png"} alt="" class="img-fluid" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
);
}
export default HomeTestimonials