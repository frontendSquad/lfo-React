
function AboutUsHome(){
 return(
    <section class="section about-sec pb-0">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-6 text-left mb-4 mb-lg-0">
                    <img src="images/about-img.png" class="img-fluid" alt="" />
                </div>
                <div class="col-12 col-lg-6 align-self-center pb-5">
                    <div class="sec-title">
                        <h5 class="text-uppercase fs-18 fw-semibold text-maroon mb-3">ABOUT OUR HISTORY</h5>
                        <h3 class="fw-bold mb-3">We Are Primarily An <br />
                            Education Consultancy</h3>
                    </div>
                    <p class="text-dark fs-18 fw-bold">offering services to high net-worth clients <br /> throughout China and the UK.</p>
                    <p class="text-light ">Our aim is to obtain school placements for our clients’ children within the
                        UK’s leading private schools. In addition to this, we also offer an application
                        service for schools and universities in the UK and USA. </p>
                    <a href="#_" class="btn btn-secondary mb-2 mb-lg-3 me-3 me-lg-3"><i><img src="images/phone-icon.png" alt="" /></i> + 123 456 7890</a>
                    <a href="#_" class="btn btn-secondary mb-2 mb-lg-3 me-3 me-lg-0"><i><img src="images/research-icon.png" alt="" /></i> Enquiry Form</a>
                    <a href="#_" class="btn btn-primary mb-2 mb-lg-3"><i><img src="images/whatsapp-icon.png" alt="" /></i>Whatsapp</a>
                </div>
            </div>
        </div>
    </section>
 );
}
export default AboutUsHome;
