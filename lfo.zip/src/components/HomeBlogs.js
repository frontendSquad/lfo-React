function HomeBlogs(){
    return(
        <section class="section latest-blog">
            <div class="container">
                <div class="row">
                    <div class="col-12 mb-3">
                        <div class="sec-title mb-2 text-center">
                            <h5 class="text-uppercase fs-18 fw-semibold text-maroon mb-2">LATEST NEWS</h5>
                            <h3 class="fw-bold mb-3">Latest From Blog</h3>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-lg-4 mb-4 mb-lg-0">
                        <div class="card blog-card">
                            <img src={process.env.PUBLIC_URL + "/images/blog-img-1.png"} alt="" className="card-img-top" />


                            
                            <div class="card-body py-4">
                                <div class="post-meta mb-3">
                                    <time class="cat-name">STUDENT</time>
                                    <time class="time-meta">JULY 15, 2021</time>
                                </div>
                                <h3 class="card-title">Make dry it is saying earth lights great brought</h3>
                                <div class="comments-meta mt-3">
                                    <ul class="mb-0 ps-0">
                                        <li><a href="#"><i class="far fa-comment-alt"></i>4 COMMENTS</a></li>
                                        <li><a href="#"><i class="far fa-heart"></i>15 LIKE</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-4 mb-4 mb-lg-0">
                        <div class="card blog-card">
                            <img src="images/blog-img-2.png" class="card-img-top" alt="..." />
                            <div class="card-body py-4">
                                <div class="post-meta mb-3">
                                    <time class="cat-name">STUDENT</time>
                                    <time class="time-meta">JULY 15, 2021</time>
                                </div>
                                <h3 class="card-title">Make dry it is saying earth lights great brought</h3>
                                <div class="comments-meta mt-3">
                                    <ul class="mb-0 ps-0">
                                        <li><a href="#"><i class="far fa-comment-alt"></i>4 COMMENTS</a></li>
                                        <li><a href="#"><i class="far fa-heart"></i>15 LIKE</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-4 mb-4 mb-lg-0">
                        <div class="card blog-card">
                            <img src="images/blog-img-3.png" class="card-img-top" alt="..." />
                            <div class="card-body py-4">
                                <div class="post-meta mb-3">
                                    <time class="cat-name">STUDENT</time>
                                    <time class="time-meta">JULY 15, 2021</time>
                                </div>
                                <h3 class="card-title">Make dry it is saying earth lights great brought</h3>
                                <div class="comments-meta mt-3">
                                    <ul class="mb-0 ps-0">
                                        <li><a href="#"><i class="far fa-comment-alt"></i>4 COMMENTS</a></li>
                                        <li><a href="#"><i class="far fa-heart"></i>15 LIKE</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 text-center mt-3 mt-lg-5 pt-2">
                        <a href="#_" class="text-uppercase btn btn-primary">LEARN MORE</a>
                    </div>
                </div>
            </div>
        </section>
    );
}
export default HomeBlogs 