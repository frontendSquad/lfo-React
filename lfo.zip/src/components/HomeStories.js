
function HomeStories(){
return(
    <section class="section stories-sec">
        <div class="container">
            <div class="row">
                <div class="col-12 col-xl-8 mx-auto">
                    <div class="row">
                        <div class="col-12 text-center">
                            <div class="sec-title mb-2">
                                <h5 class="text-uppercase fs-18 fw-semibold text-maroon mb-2">SUCCESS STORIES</h5>
                                <h3 class="fw-bold mb-3">Next Step Foundation</h3>
                            </div>
                            <p class="text-center">Seasons let creeping seasons was green a tree called bring created Shall made
                                whales very green may above dominion seed. Day wo out. Doesn creeping can called she very.
                                Beast creeping. air secod without, good shall two forth a stars every have won't seed be forth
                                Tree fruitful may May light that thating</p>
                            <a href="#_" class="text-uppercase btn btn-primary">LEARN MORE</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
);
}
export default HomeStories
